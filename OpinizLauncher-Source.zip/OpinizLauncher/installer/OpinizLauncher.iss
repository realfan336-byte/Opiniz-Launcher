#define MyAppName "Opiniz Launcher"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "Opiniz"
#define MyAppExeName "OpinizLauncher.exe"

[Setup]
AppId={{A7E57AC1-12D7-4A2B-94A1-7F7B8C83A8F2}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\Opiniz Launcher
DefaultGroupName={#MyAppName}
OutputDir=..\installer-output
OutputBaseFilename=OpinizLauncher-Setup-x64
ArchitecturesInstallIn64BitMode=x64
ArchitecturesAllowed=x64
PrivilegesRequired=lowest
DisableProgramGroupPage=yes
UninstallDisplayIcon={app}\{#MyAppExeName}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
SetupIconFile=

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Files]
Source: "..\OpinizLauncher\bin\Release\net8.0-windows\win-x64\publish\OpinizLauncher.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\Opiniz Launcher"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\Opiniz Launcher"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch Opiniz Launcher"; Flags: postinstall nowait skipifsilent
