$ErrorActionPreference = "Stop"
$project = Join-Path $PSScriptRoot "OpinizLauncher\OpinizLauncher.csproj"
dotnet publish $project -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
if ($LASTEXITCODE -ne 0) { throw "Publish failed. Install the .NET 8 SDK and run this script on Windows." }
Write-Host ""
Write-Host "Published EXE:"
Write-Host (Join-Path $PSScriptRoot "OpinizLauncher\bin\Release\net8.0-windows\win-x64\publish\OpinizLauncher.exe")
