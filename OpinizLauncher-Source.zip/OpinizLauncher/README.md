# Opiniz Launcher

A dark, Windows 11-inspired game and application launcher for Windows 10/11 (64-bit), built with C#/.NET 8 WinForms.

## Features
- Add `.exe`, `.lnk`, and `.url` items to the library
- Launch games/apps or open folders
- Search and filter the library
- Rename entries, set launch arguments, open file location, remove entries
- Persists the library in `%LOCALAPPDATA%\OpinizLauncher\library.json`
- Splash/loading screen
- Does not require administrator rights and does not delete target files

## Build requirements
- Windows 10/11 x64
- .NET 8 SDK (Windows)
- Optional: Inno Setup 6 to create the installer

## Build a portable single-file executable
Open PowerShell in the folder containing `OpinizLauncher.sln` and run:

```powershell
dotnet publish .\OpinizLauncher\OpinizLauncher.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
```

The EXE will be in:
`OpinizLauncher\bin\Release\net8.0-windows\win-x64\publish\OpinizLauncher.exe`

It is self-contained, so the .NET runtime does not need to be installed on the target PC.

## Create a setup installer (custom install location)
1. Install Inno Setup 6 from its official website.
2. Publish the app using the command above.
3. Open `installer\OpinizLauncher.iss` in Inno Setup Compiler.
4. If the publish folder path differs, update `Source` in the `.iss` file.
5. Click **Build > Compile**. The installer EXE is created in the `installer-output` folder.
6. The setup lets users choose an install location. The library remains in the user's Local AppData so updates/reinstalls don't normally erase it.

## Notes
- The project targets `net8.0-windows` and `win-x64`; it is for 64-bit Windows 10/11, not Android.
- This source has not been compiled or tested in this environment. Build on Windows with the .NET 8 SDK.
- `.lnk` and `.url` are passed to Windows shell execution; whether a given URL shortcut launches depends on Windows file associations.
