using System.Diagnostics;
using System.Drawing.Drawing2D;
using System.Text.Json;

namespace OpinizLauncher;

public sealed class LauncherForm : Form
{
    readonly Color bg = Color.FromArgb(15, 18, 27);
    readonly Color panel = Color.FromArgb(23, 28, 41);
    readonly Color panel2 = Color.FromArgb(31, 38, 54);
    readonly Color accent = Color.FromArgb(107, 92, 255);
    readonly Color text = Color.FromArgb(238, 241, 250);
    readonly Color muted = Color.FromArgb(151, 160, 181);
    readonly string dataDir = System.IO.Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "OpinizLauncher");
    readonly string dataFile;
    readonly List<LauncherItem> items = new();
    readonly FlowLayoutPanel cards = new();
    readonly TextBox searchBox = new();
    readonly Label countLabel = new();
    readonly Label statusLabel = new();
    readonly Panel content = new();
    string activeFilter = "All";
    bool loading = true;

    public LauncherForm()
    {
        dataFile = System.IO.Path.Combine(dataDir, "library.json");
        Text = "Opiniz Launcher";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(900, 600);
        Size = new Size(1220, 780);
        BackColor = bg;
        ForeColor = text;
        Font = new Font("Segoe UI", 10f);
        DoubleBuffered = true;
        ShowInTaskbar = true;
        BuildShell();
        Shown += async (_, _) =>
        {
            await Task.Delay(650);
            LoadLibrary();
            loading = false;
            content.Visible = true;
            RenderCards();
            statusLabel.Text = "Ready • Your library is saved on this PC";
        };
    }

    void BuildShell()
    {
        var header = new Panel { Dock = DockStyle.Top, Height = 82, BackColor = bg, Padding = new Padding(26, 15, 24, 12) };
        var logo = new Label { Text = "OPINIZ", Font = new Font("Segoe UI", 20, FontStyle.Bold), ForeColor = text, AutoSize = true, Location = new Point(24, 12) };
        var logoSub = new Label { Text = "L A U N C H E R", Font = new Font("Segoe UI", 8, FontStyle.Bold), ForeColor = accent, AutoSize = true, Location = new Point(28, 48) };
        var addBtn = MakeButton("+  Add game / app", accent, 160, 42);
        addBtn.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        addBtn.Location = new Point(Width - 220, 18);
        addBtn.Click += (_, _) => AddItem();
        header.Controls.Add(logo); header.Controls.Add(logoSub); header.Controls.Add(addBtn);
        header.Resize += (_, _) => addBtn.Location = new Point(header.ClientSize.Width - addBtn.Width - 4, 18);
        Controls.Add(header);

        var sidebar = new Panel { Dock = DockStyle.Left, Width = 208, BackColor = panel, Padding = new Padding(14, 22, 12, 12) };
        var libraryHeading = new Label { Text = "LIBRARY", ForeColor = muted, Font = new Font("Segoe UI", 9, FontStyle.Bold), AutoSize = true, Location = new Point(18, 18) };
        sidebar.Controls.Add(libraryHeading);
        int y = 54;
        foreach (var f in new[] { ("All", "▦   All items"), ("Game", "🎮  Games"), ("App", "▣   Applications"), ("Folder", "▰   Folders") })
        {
            var b = MakeButton(f.Item2, f.Item1 == "All" ? panel2 : panel, 174, 40);
            b.TextAlign = ContentAlignment.MiddleLeft;
            b.Padding = new Padding(12, 0, 0, 0);
            b.Location = new Point(0, y);
            b.Click += (_, _) => { activeFilter = f.Item1; UpdateNav(sidebar, f.Item1); RenderCards(); };
            b.Tag = f.Item1;
            sidebar.Controls.Add(b);
            y += 48;
        }
        var footer = new Label { Text = "OPINIZ LAUNCHER\nWindows 10 / 11 • x64", ForeColor = muted, Font = new Font("Segoe UI", 8), AutoSize = true, Location = new Point(14, 400) };
        sidebar.Controls.Add(footer);
        Controls.Add(sidebar);

        content.Dock = DockStyle.Fill;
        content.BackColor = bg;
        content.Padding = new Padding(26, 22, 26, 18);
        content.Visible = false;
        Controls.Add(content);
        content.BringToFront();
        sidebar.BringToFront();
        header.BringToFront();

        var title = new Label { Text = "Your library", Font = new Font("Segoe UI", 24, FontStyle.Bold), ForeColor = text, AutoSize = true, Location = new Point(26, 22) };
        var subtitle = new Label { Text = "Everything you play, all in one place.", Font = new Font("Segoe UI", 10), ForeColor = muted, AutoSize = true, Location = new Point(28, 62) };
        content.Controls.Add(title); content.Controls.Add(subtitle);

        searchBox.PlaceholderText = "Search games and apps...";
        searchBox.BorderStyle = BorderStyle.FixedSingle;
        searchBox.BackColor = panel;
        searchBox.ForeColor = text;
        searchBox.Font = new Font("Segoe UI", 10);
        searchBox.Size = new Size(260, 38);
        searchBox.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        searchBox.Location = new Point(content.ClientSize.Width - 286, 28);
        searchBox.TextChanged += (_, _) => RenderCards();
        content.Controls.Add(searchBox);
        content.Resize += (_, _) => searchBox.Location = new Point(content.ClientSize.Width - searchBox.Width - 4, 28);

        countLabel.Text = "0 ITEMS";
        countLabel.Font = new Font("Segoe UI", 9, FontStyle.Bold);
        countLabel.ForeColor = muted;
        countLabel.AutoSize = true;
        countLabel.Location = new Point(28, 112);
        content.Controls.Add(countLabel);

        cards.Dock = DockStyle.Fill;
        cards.Location = new Point(26, 138);
        cards.Padding = new Padding(0, 8, 0, 12);
        cards.AutoScroll = true;
        cards.BackColor = bg;
        cards.WrapContents = true;
        cards.FlowDirection = FlowDirection.LeftToRight;
        content.Controls.Add(cards);

        statusLabel.Dock = DockStyle.Bottom;
        statusLabel.Height = 30;
        statusLabel.TextAlign = ContentAlignment.MiddleLeft;
        statusLabel.ForeColor = muted;
        statusLabel.BackColor = bg;
        statusLabel.Padding = new Padding(12, 0, 0, 0);
        Controls.Add(statusLabel);
        statusLabel.BringToFront();

        var splash = new Panel { Name = "splash", Dock = DockStyle.Fill, BackColor = bg };
        var splashTitle = new Label { Text = "OPINIZ", Font = new Font("Segoe UI", 32, FontStyle.Bold), ForeColor = text, AutoSize = true };
        var splashSub = new Label { Text = "PREPARING YOUR GAME LIBRARY", Font = new Font("Segoe UI", 9, FontStyle.Bold), ForeColor = accent, AutoSize = true };
        var spinner = new ProgressBar { Style = ProgressBarStyle.Marquee, MarqueeAnimationSpeed = 28, Width = 240, Height = 8 };
        splash.Controls.Add(splashTitle); splash.Controls.Add(splashSub); splash.Controls.Add(spinner);
        splash.Resize += (_, _) =>
        {
            splashTitle.Location = new Point((splash.ClientSize.Width - splashTitle.Width) / 2, splash.ClientSize.Height / 2 - 72);
            splashSub.Location = new Point((splash.ClientSize.Width - splashSub.Width) / 2, splash.ClientSize.Height / 2 - 22);
            spinner.Location = new Point((splash.ClientSize.Width - spinner.Width) / 2, splash.ClientSize.Height / 2 + 20);
        };
        Controls.Add(splash); splash.BringToFront();
        Shown += (_, _) =>
        {
            splashTitle.Location = new Point((splash.ClientSize.Width - splashTitle.Width) / 2, splash.ClientSize.Height / 2 - 72);
            splashSub.Location = new Point((splash.ClientSize.Width - splashSub.Width) / 2, splash.ClientSize.Height / 2 - 22);
            spinner.Location = new Point((splash.ClientSize.Width - spinner.Width) / 2, splash.ClientSize.Height / 2 + 20);
        };
        Shown += async (_, _) => { await Task.Delay(650); splash.Visible = false; };
    }

    void UpdateNav(Panel sidebar, string selected)
    {
        foreach (Control c in sidebar.Controls)
            if (c is Button b && b.Tag is string tag)
                b.BackColor = tag == selected ? panel2 : panel;
    }

    Button MakeButton(string label, Color color, int width, int height)
    {
        var b = new Button
        {
            Text = label, Width = width, Height = height, FlatStyle = FlatStyle.Flat,
            BackColor = color, ForeColor = text, Font = new Font("Segoe UI", 9, FontStyle.Bold),
            Cursor = Cursors.Hand, UseVisualStyleBackColor = false
        };
        b.FlatAppearance.BorderSize = 0;
        b.FlatAppearance.MouseOverBackColor = Color.FromArgb(Math.Min(255, color.R + 12), Math.Min(255, color.G + 12), Math.Min(255, color.B + 12));
        return b;
    }

    void LoadLibrary()
    {
        try
        {
            Directory.CreateDirectory(dataDir);
            if (File.Exists(dataFile))
            {
                var loaded = JsonSerializer.Deserialize<List<LauncherItem>>(File.ReadAllText(dataFile));
                if (loaded != null) items.AddRange(loaded);
            }
            else
            {
                items.Add(new LauncherItem { Name = "Add your first game", Path = "", Kind = "Game" });
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Couldn't read your library:\n{ex.Message}", "Opiniz Launcher", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    void SaveLibrary()
    {
        try
        {
            Directory.CreateDirectory(dataDir);
            File.WriteAllText(dataFile, JsonSerializer.Serialize(items, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Couldn't save your library:\n{ex.Message}", "Save error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    void AddItem()
    {
        using var dialog = new OpenFileDialog
        {
            Title = "Choose a game or application",
            Filter = "Windows programs and shortcuts (*.exe;*.lnk;*.url)|*.exe;*.lnk;*.url|All files (*.*)|*.*",
            CheckFileExists = true
        };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        var path = dialog.FileName;
        var name = System.IO.Path.GetFileNameWithoutExtension(path);
        var kind = MessageBox.Show("Choose Yes for Game, No for Application.", "Add to library", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
        if (kind == DialogResult.Cancel) return;
        items.RemoveAll(x => string.Equals(x.Path, path, StringComparison.OrdinalIgnoreCase));
        items.Add(new LauncherItem
        {
            Name = name,
            Path = path,
            Kind = kind == DialogResult.Yes ? "Game" : "App",
            WorkingDirectory = System.IO.Path.GetDirectoryName(path) ?? ""
        });
        SaveLibrary();
        RenderCards();
        statusLabel.Text = $"Added {name}";
    }

    void AddFolder()
    {
        using var dialog = new FolderBrowserDialog { Description = "Choose a folder to add to your launcher" };
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        var path = dialog.SelectedPath;
        items.RemoveAll(x => string.Equals(x.Path, path, StringComparison.OrdinalIgnoreCase));
        items.Add(new LauncherItem { Name = System.IO.Path.GetFileName(path.TrimEnd('\\')) is string n && n.Length > 0 ? n : path, Path = path, Kind = "Folder", WorkingDirectory = path });
        SaveLibrary(); RenderCards();
    }

    void RenderCards()
    {
        if (loading) return;
        cards.SuspendLayout();
        cards.Controls.Clear();
        var query = searchBox.Text.Trim();
        var filtered = items.Where(x =>
            (activeFilter == "All" || x.Kind == activeFilter) &&
            (string.IsNullOrWhiteSpace(query) || x.Name.Contains(query, StringComparison.OrdinalIgnoreCase) || x.Path.Contains(query, StringComparison.OrdinalIgnoreCase))
        ).ToList();
        countLabel.Text = $"{filtered.Count} ITEM{(filtered.Count == 1 ? "" : "S")}";
        foreach (var item in filtered)
        {
            if (string.IsNullOrWhiteSpace(item.Path)) continue;
            cards.Controls.Add(CreateCard(item));
        }
        if (filtered.Count == 0)
        {
            var empty = new Label { Text = "Nothing here yet. Click “Add game / app” to get started.", ForeColor = muted, Font = new Font("Segoe UI", 11), AutoSize = true, Padding = new Padding(8, 18, 8, 8) };
            cards.Controls.Add(empty);
        }
        cards.ResumeLayout();
    }

    Control CreateCard(LauncherItem item)
    {
        var card = new Panel { Width = 240, Height = 184, BackColor = panel, Margin = new Padding(0, 0, 16, 16), Padding = new Padding(16) };
        var glyph = new Label { Text = item.Kind == "Game" ? "🎮" : item.Kind == "Folder" ? "📁" : "▣", Font = new Font("Segoe UI Emoji", 24), AutoSize = true, Location = new Point(15, 12) };
        var kind = new Label { Text = item.Kind.ToUpperInvariant(), ForeColor = accent, Font = new Font("Segoe UI", 8, FontStyle.Bold), AutoSize = true, Location = new Point(16, 65) };
        var name = new Label { Text = item.Name, ForeColor = text, Font = new Font("Segoe UI", 12, FontStyle.Bold), AutoSize = false, Width = 205, Height = 28, Location = new Point(16, 86), AutoEllipsis = true };
        var path = new Label { Text = item.Path, ForeColor = muted, Font = new Font("Segoe UI", 8), AutoSize = false, Width = 205, Height = 24, Location = new Point(16, 113), AutoEllipsis = true };
        var launch = MakeButton(item.Kind == "Folder" ? "Open folder" : "▶  Launch", accent, 124, 32);
        launch.Location = new Point(14, 143);
        launch.Click += (_, _) => Launch(item);
        var more = MakeButton("•••", panel2, 46, 32);
        more.Location = new Point(154, 143);
        more.Click += (_, _) => ShowItemMenu(item, more);
        card.Controls.Add(glyph); card.Controls.Add(kind); card.Controls.Add(name); card.Controls.Add(path); card.Controls.Add(launch); card.Controls.Add(more);
        card.Paint += (_, e) =>
        {
            using var pen = new Pen(Color.FromArgb(44, 52, 73));
            e.Graphics.DrawRectangle(pen, 0, 0, card.Width - 1, card.Height - 1);
        };
        return card;
    }

    void ShowItemMenu(LauncherItem item, Control owner)
    {
        var menu = new ContextMenuStrip();
        menu.Items.Add("Rename", null, (_, _) => RenameItem(item));
        menu.Items.Add("Edit launch arguments…", null, (_, _) => EditArguments(item));
        menu.Items.Add("Open file location", null, (_, _) => OpenLocation(item));
        menu.Items.Add("Add folder…", null, (_, _) => AddFolder());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Remove from library", null, (_, _) =>
        {
            if (MessageBox.Show($"Remove {item.Name} from the library? The file will not be deleted.", "Remove item", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            { items.Remove(item); SaveLibrary(); RenderCards(); }
        });
        menu.Show(owner, new Point(0, owner.Height));
    }

    void RenameItem(LauncherItem item)
    {
        using var form = new Form { Text = "Rename item", FormBorderStyle = FormBorderStyle.FixedDialog, StartPosition = FormStartPosition.CenterParent, ClientSize = new Size(360, 125), BackColor = panel, ForeColor = text, MinimizeBox = false, MaximizeBox = false };
        var box = new TextBox { Text = item.Name, Location = new Point(16, 18), Width = 328, BackColor = panel2, ForeColor = text, BorderStyle = BorderStyle.FixedSingle };
        var ok = MakeButton("Save", accent, 90, 32); ok.Location = new Point(254, 67); ok.DialogResult = DialogResult.OK;
        form.Controls.Add(box); form.Controls.Add(ok); form.AcceptButton = ok;
        if (form.ShowDialog(this) == DialogResult.OK && !string.IsNullOrWhiteSpace(box.Text)) { item.Name = box.Text.Trim(); SaveLibrary(); RenderCards(); }
    }

    void EditArguments(LauncherItem item)
    {
        var args = Microsoft.VisualBasic.Interaction.InputBox("Optional command-line arguments:", "Launch arguments", item.Arguments);
        if (args != null) { item.Arguments = args; SaveLibrary(); statusLabel.Text = "Launch arguments saved"; }
    }

    void OpenLocation(LauncherItem item)
    {
        try
        {
            if (item.Kind == "Folder" && Directory.Exists(item.Path)) Process.Start(new ProcessStartInfo(item.Path) { UseShellExecute = true });
            else if (File.Exists(item.Path)) Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{item.Path}\"") { UseShellExecute = true });
            else MessageBox.Show("That path no longer exists.", "Path not found", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Couldn't open location", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }

    void Launch(LauncherItem item)
    {
        try
        {
            if (item.Kind == "Folder")
            {
                if (!Directory.Exists(item.Path)) throw new FileNotFoundException("Folder not found.", item.Path);
                Process.Start(new ProcessStartInfo(item.Path) { UseShellExecute = true });
            }
            else
            {
                if (!File.Exists(item.Path)) throw new FileNotFoundException("The selected file could not be found.", item.Path);
                var start = new ProcessStartInfo(item.Path)
                {
                    UseShellExecute = true,
                    WorkingDirectory = string.IsNullOrWhiteSpace(item.WorkingDirectory) ? System.IO.Path.GetDirectoryName(item.Path) ?? "" : item.WorkingDirectory,
                    Arguments = item.Arguments ?? ""
                };
                Process.Start(start);
            }
            statusLabel.Text = $"Launched {item.Name}";
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Couldn't launch {item.Name}.\n\n{ex.Message}\n\nIf the file was moved, remove it and add it again.", "Launch failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
