namespace OpinizLauncher;

public sealed class LauncherItem
{
    public string Name { get; set; } = "";
    public string Path { get; set; } = "";
    public string Kind { get; set; } = "Game";
    public string Arguments { get; set; } = "";
    public string WorkingDirectory { get; set; } = "";
}
